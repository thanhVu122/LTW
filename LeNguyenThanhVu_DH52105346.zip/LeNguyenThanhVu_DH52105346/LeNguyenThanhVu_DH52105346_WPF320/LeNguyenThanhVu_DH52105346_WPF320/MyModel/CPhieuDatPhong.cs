﻿

namespace LeNguyenThanhVu_DH52105346_WPF320.MyModel
{
    public class CPhieuDatPhong
    {
        public string Mapdp { get; set; } = null!;
        public DateTime? Ngaydat { get; set; }
        public DateTime? Ngaybd { get; set; }
        public DateTime? Ngaykt { get; set; }
        public string? Makh { get; set; }

     
        public string ngayDatNew
        {
            get
            {
                return Ngaydat.Value.ToShortDateString();
            }
        }
        public string ngaybdNew
        {
            get
            {
                return Ngaybd.Value.ToShortDateString();
            }
        }
        public string ngayktNew
        {
            get
            {
                return Ngaykt.Value.ToShortDateString();
            }
        }

    }
}
