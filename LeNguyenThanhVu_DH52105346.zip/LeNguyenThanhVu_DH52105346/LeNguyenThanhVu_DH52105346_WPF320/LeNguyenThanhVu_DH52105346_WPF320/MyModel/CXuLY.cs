﻿using LeNguyenThanhVu_DH52105346_API320.MyModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace LeNguyenThanhVu_DH52105346_WPF320.MyModel
{
    class CXuLY
    {
        private static string URL = @"https://localhost:7113/api/PhieuDatPhong";

        public static List<CPhieuDatPhong> GetCPhieuDatPhongs()
        {
            try
            {
                HttpClient hc = new HttpClient();
                var res = hc.GetFromJsonAsync<List<CPhieuDatPhong>>(URL);
                res.Wait();
                return res.Result;
            }
            catch
            {
                return null;
            }
        }
        public static List<CLoaiPhong> GetCLoaiPhongs()
        {
            try
            {
                string urlLoaiPhong = @"https://localhost:7113/api/PhieuDatPhong/MaLoaiPhong";
                HttpClient hc = new HttpClient();
                var res = hc.GetFromJsonAsync<List<CLoaiPhong>>(urlLoaiPhong);
                res.Wait();
                return res.Result;
            }
            catch
            {
                return null;
            }
        }

        

    }
}
