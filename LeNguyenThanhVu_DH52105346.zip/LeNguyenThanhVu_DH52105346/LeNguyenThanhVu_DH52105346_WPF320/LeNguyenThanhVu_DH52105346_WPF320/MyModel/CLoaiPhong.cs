﻿
namespace LeNguyenThanhVu_DH52105346_API320.MyModel
{
    public class CLoaiPhong
    {
        public string Maloai { get; set; } = null!;
        public int? Songuoi { get; set; }
        public double? Dongia { get; set; }
     
    }
}
