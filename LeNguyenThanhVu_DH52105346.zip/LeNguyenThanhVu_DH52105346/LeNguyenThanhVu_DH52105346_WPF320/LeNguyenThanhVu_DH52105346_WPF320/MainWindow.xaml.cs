﻿using LeNguyenThanhVu_DH52105346_API320.MyModel;
using LeNguyenThanhVu_DH52105346_WPF320.MyModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LeNguyenThanhVu_DH52105346_WPF320;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{

    public MainWindow()
    {
        InitializeComponent();
    }
    private void hienThi()
    {
        List<CPhieuDatPhong> ds = CXuLY.GetCPhieuDatPhongs();
        if (ds == null)
        {
            MessageBox.Show("Lỗi kết nối");
            return;
        }
        dgPhieuDatPhong.ItemsSource = ds;
        List<CLoaiPhong> dstg = CXuLY.GetCLoaiPhongs();
        if (dstg != null) 
            cmbLoaiPhong.ItemsSource = dstg.ToList();
        else 
            MessageBox.Show("Lỗi đọc danh sách tác giả!");
    }

  
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        hienThi();

    }

    private void dgPhieuDatPhong_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        gridPhong.DataContext = dgPhieuDatPhong.SelectedItem;
    }
}