﻿using System;
using System.Collections.Generic;

namespace LeNguyenThanhVu_DH52105346_API320.Models
{
    public partial class Khachhang
    {
        public Khachhang()
        {
            Phieudatphongs = new HashSet<Phieudatphong>();
        }

        public string Makh { get; set; } = null!;
        public string? Tenkh { get; set; }
        public string? Email { get; set; }
        public string? Sodt { get; set; }

        public virtual ICollection<Phieudatphong> Phieudatphongs { get; set; }
    }
}
