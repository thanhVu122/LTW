﻿using System;
using System.Collections.Generic;

namespace LeNguyenThanhVu_DH52105346_API320.Models
{
    public partial class Loaiphong
    {
        public Loaiphong()
        {
            ChitietPhieudatphongs = new HashSet<ChitietPhieudatphong>();
        }

        public string Maloai { get; set; } = null!;
        public int? Songuoi { get; set; }
        public double? Dongia { get; set; }

        public virtual ICollection<ChitietPhieudatphong> ChitietPhieudatphongs { get; set; }
    }
}
