﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace LeNguyenThanhVu_DH52105346_API320.Models
{
    public partial class datphongContext : DbContext
    {
        public datphongContext()
        {
        }

        public datphongContext(DbContextOptions<datphongContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ChitietPhieudatphong> ChitietPhieudatphongs { get; set; } = null!;
        public virtual DbSet<Khachhang> Khachhangs { get; set; } = null!;
        public virtual DbSet<Loaiphong> Loaiphongs { get; set; } = null!;
        public virtual DbSet<Phieudatphong> Phieudatphongs { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=(local);Initial Catalog=QLDP;Integrated Security=True;Trust Server Certificate=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ChitietPhieudatphong>(entity =>
            {
                entity.HasKey(e => new { e.Mapdp, e.Maloai });

                entity.ToTable("chitietPhieudatphong");

                entity.Property(e => e.Mapdp)
                    .HasMaxLength(50)
                    .HasColumnName("mapdp");

                entity.Property(e => e.Maloai)
                    .HasMaxLength(50)
                    .HasColumnName("maloai");

                entity.Property(e => e.Dongia).HasColumnName("dongia");

                entity.Property(e => e.Soluong).HasColumnName("soluong");

                entity.HasOne(d => d.MaloaiNavigation)
                    .WithMany(p => p.ChitietPhieudatphongs)
                    .HasForeignKey(d => d.Maloai)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_chitietPhieudatphong_loaiphong");

                entity.HasOne(d => d.MapdpNavigation)
                    .WithMany(p => p.ChitietPhieudatphongs)
                    .HasForeignKey(d => d.Mapdp)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_chitietPhieudatphong_phieudatphong");
            });

            modelBuilder.Entity<Khachhang>(entity =>
            {
                entity.HasKey(e => e.Makh);

                entity.ToTable("khachhang");

                entity.Property(e => e.Makh)
                    .HasMaxLength(50)
                    .HasColumnName("makh");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .HasColumnName("email");

                entity.Property(e => e.Sodt)
                    .HasMaxLength(50)
                    .HasColumnName("sodt");

                entity.Property(e => e.Tenkh)
                    .HasMaxLength(50)
                    .HasColumnName("tenkh");
            });

            modelBuilder.Entity<Loaiphong>(entity =>
            {
                entity.HasKey(e => e.Maloai);

                entity.ToTable("loaiphong");

                entity.Property(e => e.Maloai)
                    .HasMaxLength(50)
                    .HasColumnName("maloai");

                entity.Property(e => e.Dongia).HasColumnName("dongia");

                entity.Property(e => e.Songuoi).HasColumnName("songuoi");
            });

            modelBuilder.Entity<Phieudatphong>(entity =>
            {
                entity.HasKey(e => e.Mapdp);

                entity.ToTable("phieudatphong");

                entity.Property(e => e.Mapdp)
                    .HasMaxLength(50)
                    .HasColumnName("mapdp");

                entity.Property(e => e.Makh)
                    .HasMaxLength(50)
                    .HasColumnName("makh");

                entity.Property(e => e.Ngaybd)
                    .HasColumnType("date")
                    .HasColumnName("ngaybd");

                entity.Property(e => e.Ngaydat)
                    .HasColumnType("date")
                    .HasColumnName("ngaydat");

                entity.Property(e => e.Ngaykt)
                    .HasColumnType("date")
                    .HasColumnName("ngaykt");

                entity.HasOne(d => d.MakhNavigation)
                    .WithMany(p => p.Phieudatphongs)
                    .HasForeignKey(d => d.Makh)
                    .HasConstraintName("FK_phieudatphong_khachhang");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
