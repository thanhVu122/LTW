﻿using System;
using System.Collections.Generic;

namespace LeNguyenThanhVu_DH52105346_API320.Models
{
    public partial class Phieudatphong
    {
        public Phieudatphong()
        {
            ChitietPhieudatphongs = new HashSet<ChitietPhieudatphong>();
        }

        public string Mapdp { get; set; } = null!;
        public DateTime? Ngaydat { get; set; }
        public DateTime? Ngaybd { get; set; }
        public DateTime? Ngaykt { get; set; }
        public string? Makh { get; set; }

        public virtual Khachhang? MakhNavigation { get; set; }
        public virtual ICollection<ChitietPhieudatphong> ChitietPhieudatphongs { get; set; }
    }
}
