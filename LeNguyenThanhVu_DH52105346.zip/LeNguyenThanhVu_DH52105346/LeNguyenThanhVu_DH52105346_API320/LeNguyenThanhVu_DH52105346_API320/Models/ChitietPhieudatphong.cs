﻿using System;
using System.Collections.Generic;

namespace LeNguyenThanhVu_DH52105346_API320.Models
{
    public partial class ChitietPhieudatphong
    {
        public string Mapdp { get; set; } = null!;
        public string Maloai { get; set; } = null!;
        public double? Dongia { get; set; }
        public int? Soluong { get; set; }

        public virtual Loaiphong MaloaiNavigation { get; set; } = null!;
        public virtual Phieudatphong MapdpNavigation { get; set; } = null!;
    }
}
