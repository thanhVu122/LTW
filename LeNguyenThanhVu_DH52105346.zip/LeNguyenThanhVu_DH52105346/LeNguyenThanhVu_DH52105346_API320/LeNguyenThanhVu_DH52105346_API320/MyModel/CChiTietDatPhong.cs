﻿namespace LeNguyenThanhVu_DH52105346_API320.MyModel
{
    public class CChiTietDatPhong
    {
        public string Mapdp { get; set; } = null!;
        public string Maloai { get; set; } = null!;
        public double? Dongia { get; set; }
        public int? Soluong { get; set; }

    }
}
