﻿using LeNguyenThanhVu_DH52105346_API320.Models;

namespace LeNguyenThanhVu_DH52105346_API320.MyModel
{
    public class CPhieuDatPhong
    {
        public string Mapdp { get; set; } = null!;
        public DateTime? Ngaydat { get; set; }
        public DateTime? Ngaybd { get; set; }
        public DateTime? Ngaykt { get; set; }
        public string? Makh { get; set; }

        public static CPhieuDatPhong chuyenDoi(Phieudatphong phieu)
        {
            return new CPhieuDatPhong
            {
                Mapdp = phieu.Mapdp,
                Ngaydat = phieu.Ngaydat,
                Ngaybd = phieu.Ngaybd,
                Ngaykt = phieu.Ngaykt,
                Makh = phieu.Makh
            };
        }


    }
}
