﻿using LeNguyenThanhVu_DH52105346_API320.Models;

namespace LeNguyenThanhVu_DH52105346_API320.MyModel
{
    public class CLoaiPhong
    {
        public string Maloai { get; set; } = null!;
        public int? Songuoi { get; set; }
        public double? Dongia { get; set; }
        public static CLoaiPhong chuyenDoi(Loaiphong loai)
        {
            return new CLoaiPhong
            {
                Maloai = loai.Maloai,
                Songuoi = loai.Songuoi,
                Dongia = loai.Dongia
            };
        }
    }
}
