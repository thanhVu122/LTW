﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LeNguyenThanhVu_DH52105346_API320.Migrations
{
    public partial class AddDatabase : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "khachhang",
                columns: table => new
                {
                    makh = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    tenkh = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    email = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    sodt = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_khachhang", x => x.makh);
                });

            migrationBuilder.CreateTable(
                name: "loaiphong",
                columns: table => new
                {
                    maloai = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    songuoi = table.Column<int>(type: "int", nullable: true),
                    dongia = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_loaiphong", x => x.maloai);
                });

            migrationBuilder.CreateTable(
                name: "phieudatphong",
                columns: table => new
                {
                    mapdp = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ngaydat = table.Column<DateTime>(type: "date", nullable: true),
                    ngaybd = table.Column<DateTime>(type: "date", nullable: true),
                    ngaykt = table.Column<DateTime>(type: "date", nullable: true),
                    makh = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_phieudatphong", x => x.mapdp);
                    table.ForeignKey(
                        name: "FK_phieudatphong_khachhang",
                        column: x => x.makh,
                        principalTable: "khachhang",
                        principalColumn: "makh");
                });

            migrationBuilder.CreateTable(
                name: "chitietPhieudatphong",
                columns: table => new
                {
                    mapdp = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    maloai = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    dongia = table.Column<double>(type: "float", nullable: true),
                    soluong = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_chitietPhieudatphong", x => new { x.mapdp, x.maloai });
                    table.ForeignKey(
                        name: "FK_chitietPhieudatphong_loaiphong",
                        column: x => x.maloai,
                        principalTable: "loaiphong",
                        principalColumn: "maloai");
                    table.ForeignKey(
                        name: "FK_chitietPhieudatphong_phieudatphong",
                        column: x => x.mapdp,
                        principalTable: "phieudatphong",
                        principalColumn: "mapdp");
                });

            migrationBuilder.CreateIndex(
                name: "IX_chitietPhieudatphong_maloai",
                table: "chitietPhieudatphong",
                column: "maloai");

            migrationBuilder.CreateIndex(
                name: "IX_phieudatphong_makh",
                table: "phieudatphong",
                column: "makh");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "chitietPhieudatphong");

            migrationBuilder.DropTable(
                name: "loaiphong");

            migrationBuilder.DropTable(
                name: "phieudatphong");

            migrationBuilder.DropTable(
                name: "khachhang");
        }
    }
}
