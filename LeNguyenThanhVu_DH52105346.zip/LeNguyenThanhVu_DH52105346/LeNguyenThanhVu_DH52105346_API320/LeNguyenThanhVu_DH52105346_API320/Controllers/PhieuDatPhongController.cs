﻿using LeNguyenThanhVu_DH52105346_API320.Models;
using LeNguyenThanhVu_DH52105346_API320.MyModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LeNguyenThanhVu_DH52105346_API320.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PhieuDatPhongController : ControllerBase
    {
        [HttpGet]
        public IActionResult getPhieuDatPhong()
        {
            try
            {
                datphongContext db = new datphongContext();
                List<CPhieuDatPhong> ds = db.Phieudatphongs
                    .Select(c => CPhieuDatPhong.chuyenDoi(c))
                    .ToList();
                return Ok(ds);
            }
            catch
            {
                return BadRequest();
            }
        }
        [HttpGet("MaLoaiPhong")]
        public IActionResult getDsMaLoaiPhong()
        {
            try
            {
                datphongContext db = new datphongContext();
                List<CLoaiPhong> ds = db.Loaiphongs
               .Select(x => CLoaiPhong.chuyenDoi(x))
               .ToList();
                return Ok(ds);
            }
            catch
            {
                return BadRequest();

            }
        }
  
        //[HttpGet("{mapdp}")]
        //public async Task<IActionResult> GetPhieuDatPhongDetails(string mapdp)
        //{
        //    datphongContext db = new datphongContext();
        //    var phieuDatPhong = await db.Phieudatphongs
        //        .Include(p => p.MakhNavigation) // Lấy thông tin khách hàng
        //        .Include(p => p.ChitietPhieudatphongs)
        //            .ThenInclude(ct => ct.MaloaiNavigation) // Lấy thông tin loại phòng
        //        .FirstOrDefaultAsync(p => p.Mapdp == mapdp);

        //    if (phieuDatPhong == null)
        //    {
        //        return NotFound();
        //    }

        //    return Ok(phieuDatPhong);
        //}


    }
}
